@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Desativar Xbox Game Bar DVR (Gravacao de Fundo)
color 0E
echo ===============================================================================
echo                 APEX BOOST - DESATIVAR XBOX GAME BAR DVR
echo ===============================================================================
echo.
echo A gravacao automatica em segundo plano do Windows rouba ate 20%% do seu FPS.
echo Desativando recursos de captura em segundo plano...
reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f >nul 2>&1
echo.
echo [CONCLUIDO] Xbox Game Bar DVR desativado! Mais FPS para seus jogos.
echo.
pause
