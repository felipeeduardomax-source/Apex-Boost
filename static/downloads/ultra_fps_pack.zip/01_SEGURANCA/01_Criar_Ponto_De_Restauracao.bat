@echo off
title Apex Boost Labs - Criando Ponto de Restauracao
color 0B
echo ===============================================================================
echo                      APEX BOOST - PONTO DE RESTAURACAO
echo ===============================================================================
echo.
echo Criando Ponto de Restauracao do Sistema por seguranca antes das otimizacoes...
echo.
powershell.exe -ExecutionPolicy Bypass -Command "Checkpoint-Computer -Description 'ApexBoost_PreTweak' -RestorePointType 'MODIFY_SETTINGS'"
if %errorlevel% equ 0 (
    echo.
    echo [SUCESSO] Ponto de Restauracao criado com sucesso!
) else (
    echo.
    echo [AVISO] Execute como Administrador para criar o Ponto de Restauracao.
)
echo.
pause
