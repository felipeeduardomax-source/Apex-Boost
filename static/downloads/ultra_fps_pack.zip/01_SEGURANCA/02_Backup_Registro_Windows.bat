@echo off
title Apex Boost Labs - Backup do Registro do Windows
color 0B
echo ===============================================================================
echo                      APEX BOOST - BACKUP DO REGISTRO
echo ===============================================================================
echo.
echo Exportando backup das chaves de registro do sistema...
if not exist "C:\ApexBoost_Backups" mkdir "C:\ApexBoost_Backups"
reg export "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" "C:\ApexBoost_Backups\SystemProfile_Backup.reg" /y >nul 2>&1
reg export "HKCU\Control Panel\Desktop" "C:\ApexBoost_Backups\Desktop_Backup.reg" /y >nul 2>&1
reg export "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" "C:\ApexBoost_Backups\Tcpip_Backup.reg" /y >nul 2>&1
echo.
echo [SUCESSO] Backup salvo com seguranca em: C:\ApexBoost_Backups
echo.
pause
