@echo off
title Apex Boost Labs - Otimizacao de SSD TRIM
color 0B
echo ===============================================================================
echo                       APEX BOOST - OTIMIZACAO DE SSD
echo ===============================================================================
echo.
echo Executando comando TRIM em todas as unidades SSD para máxima velocidade de leitura...
powershell.exe -ExecutionPolicy Bypass -Command "Optimize-Volume -DriveLetter C -ReTrim -Verbose"
echo.
echo [CONCLUIDO] TRIM executado com sucesso no SSD!
echo.
pause
