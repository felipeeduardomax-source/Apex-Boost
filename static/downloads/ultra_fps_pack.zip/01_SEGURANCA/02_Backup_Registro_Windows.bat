@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Backup do Registro do Windows
color 0B
echo ===============================================================================
echo                      APEX BOOST - BACKUP DO REGISTRO
echo ===============================================================================
echo.
echo Exportando backup das chaves de registro do sistema...
if not exist "C:\ApexBoost_Backups" mkdir "C:\ApexBoost_Backups" >nul 2>&1
reg export "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" "C:\ApexBoost_Backups\SystemProfile_Backup.reg" /y >nul 2>&1
reg export "HKCU\Control Panel\Desktop" "C:\ApexBoost_Backups\Desktop_Backup.reg" /y >nul 2>&1
reg export "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" "C:\ApexBoost_Backups\Tcpip_Backup.reg" /y >nul 2>&1
echo.
echo [SUCESSO] Backup salvo com seguranca em: C:\ApexBoost_Backups
echo.
pause
