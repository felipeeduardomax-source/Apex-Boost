@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Aplicar DNS Gamer de Baixa Latencia
color 0B
echo ===============================================================================
echo                APEX BOOST - DNS CLOUDFLARE 1.1.1.1 & GOOGLE
echo ===============================================================================
echo.
echo Aplicando DNS Cloudflare 1.1.1.1 (Primario) e 1.0.0.1 (Secundario) nas conexoes ativas...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Set-DnsClientServerAddress -ServerAddresses ('1.1.1.1','1.0.0.1')" >nul 2>&1
ipconfig /flushdns >nul 2>&1
echo.
echo [CONCLUIDO] DNS Gamer configurado! Rotas de conexao otimizadas.
echo.
pause
