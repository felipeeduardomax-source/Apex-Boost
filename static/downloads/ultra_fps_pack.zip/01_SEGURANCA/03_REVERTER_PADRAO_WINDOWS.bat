@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Reverter Todas as Configuracoes
color 0C
echo ===============================================================================
echo                APEX BOOST - REVERTER PARA PADRAO DO WINDOWS
echo ===============================================================================
echo.
echo Restaurando configuracoes padrao de rede, timers e energia do Windows...
echo.

echo 1. Restaurando pilha TCP/IP padrao...
netsh int ip reset >nul 2>&1
netsh int tcp reset >nul 2>&1
netsh winsock reset >nul 2>&1

echo 2. Restaurando timers bcdedit padrao...
bcdedit /deletevalue useplatformclock >nul 2>&1
bcdedit /deletevalue useplatformtick >nul 2>&1
bcdedit /deletevalue disabledynamictick >nul 2>&1

echo 3. Restaurando plano de energia padrao do Windows...
powercfg -restoredefaultschemes >nul 2>&1

echo 4. Restaurando servicos essenciais do Windows...
sc config "DiagTrack" start=auto >nul 2>&1
sc start "DiagTrack" >nul 2>&1

echo 5. Restaurando aceleracao de mouse padrao...
reg add "HKCU\Control Panel\Mouse" /v "MouseSpeed" /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold1" /t REG_SZ /d 6 /f >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold2" /t REG_SZ /d 10 /f >nul 2>&1

echo.
echo [CONCLUIDO] Configuracoes restauradas para o padrao de fabrica do Windows!
echo Recomendamos reiniciar o computador agora.
echo.
pause
