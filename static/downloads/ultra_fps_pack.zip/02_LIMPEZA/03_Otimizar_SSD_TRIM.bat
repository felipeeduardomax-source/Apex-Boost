@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Otimizacao de SSD TRIM
color 0B
echo ===============================================================================
echo                       APEX BOOST - OTIMIZACAO DE SSD
echo ===============================================================================
echo.
echo Executando comando TRIM em todas as unidades SSD para máxima velocidade...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Optimize-Volume -DriveLetter C -ReTrim -ErrorAction SilentlyContinue" >nul 2>&1
echo.
echo [CONCLUIDO] TRIM executado com sucesso no SSD!
echo.
pause
