@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - CPU Core Unparking (100% dos Nucleos Ativos)
color 0B
echo ===============================================================================
echo                   APEX BOOST - CPU CORE UNPARKING 100%
echo ===============================================================================
echo.
echo Configurando nucleos da CPU para ficarem sempre acordados em 100%...
powercfg -setacvalueindex scheme_current sub_processor CPMINCORES 100 >nul 2>&1
powercfg -setacvalueindex scheme_current sub_processor CPMAXCORES 100 >nul 2>&1
powercfg -setactive scheme_current >nul 2>&1
echo.
echo [CONCLUIDO] Nenhum nucleo do seu processador entrara mais em modo de sono durante seus jogos!
echo.
pause
