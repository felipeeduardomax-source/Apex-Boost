@echo off
title Apex Boost Labs - Otimizacao de Driver de Video GPU
color 09
echo ===============================================================================
echo                 APEX BOOST - OTIMIZACAO DE DRIVER GPU (NVIDIA/AMD)
echo ===============================================================================
echo.
echo Ajustando prioridade de GPU e agendamento de threads graficas...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /t REG_DWORD /d 6 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "SFIO Priority" /t REG_SZ /d "High" /f >nul 2>&1
echo.
echo [CONCLUIDO] Prioridade maxima de renderizacao atribuida para jogos!
echo.
pause
