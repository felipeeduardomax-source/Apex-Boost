@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Otimizador de Memoria RAM
color 0A
echo ===============================================================================
echo                   APEX BOOST - LIBERACAO DE MEMORIA RAM
echo ===============================================================================
echo.
echo Limpando lista de espera (Standby Cache) e memoria ociosa de processos...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-Process | ForEach-Object { try { $_.MinWorkingSet = $_.MinWorkingSet } catch {} }; [System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()" >nul 2>&1
echo.
echo [CONCLUIDO] Memoria RAM limpa e liberada com sucesso para seus jogos!
echo.
pause
