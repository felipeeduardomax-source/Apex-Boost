@echo off
title Apex Boost Labs - Aplicar DNS Gamer de Baixa Latencia
color 0B
echo ===============================================================================
echo                APEX BOOST - DNS CLOUDFLARE 1.1.1.1 & GOOGLE
echo ===============================================================================
echo.
echo Aplicando DNS Cloudflare 1.1.1.1 (Primario) e 1.0.0.1 (Secundario) nas conexoes ativas...
powershell.exe -ExecutionPolicy Bypass -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Set-DnsClientServerAddress -ServerAddresses ('1.1.1.1','1.0.0.1')"
ipconfig /flushdns >nul 2>&1
echo.
echo [CONCLUIDO] DNS Gamer configurado! Rotas de conexao otimizadas.
echo.
pause
