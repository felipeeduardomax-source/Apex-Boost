@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Otimizar Efeitos Visuais do Windows
color 0D
echo ===============================================================================
echo                 APEX BOOST - EFEITOS VISUAIS DE ALTO DESEMPENHO
echo ===============================================================================
echo.
echo Desativando animacoes pesadas do Windows mantendo fontes e icones nitidos...
reg add "HKCU\Control Panel\Desktop" /v "UserPreferencesMask" /t REG_BINARY /d 9012038010000000 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v "MinAnimate" /t REG_SZ /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarAnimations" /t REG_DWORD /d 0 /f >nul 2>&1
echo.
echo [CONCLUIDO] Janelas e barra de tarefas agora respondem com velocidade maxima!
echo.
pause
