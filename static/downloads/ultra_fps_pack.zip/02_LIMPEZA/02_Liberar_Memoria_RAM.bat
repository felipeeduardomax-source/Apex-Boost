@echo off
title Apex Boost Labs - Otimizador de Memoria RAM
color 0A
echo ===============================================================================
echo                   APEX BOOST - LIBERACAO DE MEMORIA RAM
echo ===============================================================================
echo.
echo Limpando lista de espera (Standby Cache) e memoria nao utilizada...
powershell.exe -ExecutionPolicy Bypass -Command "[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()"
echo.
echo [CONCLUIDO] Memoria RAM limpa e liberada para os seus jogos!
echo.
pause
