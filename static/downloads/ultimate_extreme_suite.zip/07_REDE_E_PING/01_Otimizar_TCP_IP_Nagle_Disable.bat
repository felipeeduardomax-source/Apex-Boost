@echo off
title Apex Boost Labs - TCP/IP & Network Optimizer
color 0A
echo ===============================================================================
echo                 APEX BOOST - REDE, PING BAIXO & ZERO LOSS
echo ===============================================================================
echo.
echo 1. Otimizando TCP Window Auto-Tuning e Congestionamento...
netsh int tcp set global autotuninglevel=normal >nul 2>&1
netsh int tcp set global rss=enabled >nul 2>&1
netsh int tcp set global chimney=disabled >nul 2>&1
netsh int tcp set global timestamps=disabled >nul 2>&1
netsh int tcp set global ecncapability=disabled >nul 2>&1
netsh int tcp set heuristics disabled >nul 2>&1

echo 2. Desativando Nagle Algorithm nas interfaces de rede...
for /f %%i in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"') do (
    reg add "%%i" /v "TcpAckFrequency" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "%%i" /v "TCPNoDelay" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "%%i" /v "TcpDelAckTicks" /t REG_DWORD /d 0 /f >nul 2>&1
)

echo.
echo [CONCLUIDO] Pilha TCP/IP otimizada com sucesso! Sem atraso de empacotamento Nagle.
echo.
pause
