@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Criar Ponto de Restauracao
color 0B
echo ===============================================================================
echo                      APEX BOOST - PONTO DE RESTAURACAO
echo ===============================================================================
echo.
echo Ativando Protecao do Sistema e criando Ponto de Restauracao de Seguranca...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Enable-ComputerRestore -Drive 'C:\' -ErrorAction SilentlyContinue; Checkpoint-Computer -Description 'ApexBoost_PreTweak' -RestorePointType 'MODIFY_SETTINGS' -ErrorAction SilentlyContinue" >nul 2>&1
echo.
echo [SUCESSO] Ponto de Restauracao do Windows processado com seguranca!
echo Caso deseje desfazer qualquer alteracao no futuro, basta restaurar este ponto.
echo.
pause
