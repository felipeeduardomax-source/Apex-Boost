@echo off
title Apex Boost Labs - Ativar Plano Ultimate Performance Apex
color 0D
echo ===============================================================================
echo                      APEX BOOST - PLANO DE ENERGIA MAXIMA
echo ===============================================================================
echo.
echo Desbloqueando Plano de Desempenho Maximo do Windows...
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 >nul 2>&1
powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61 >nul 2>&1
echo.
echo [CONCLUIDO] Plano 'Desempenho Maximo' ativado e selecionado com sucesso!
echo.
pause
