@echo off
title Apex Boost Labs - Desativar HPET (High Precision Event Timer)
color 0C
echo ===============================================================================
echo                      APEX BOOST - DESATIVAR HPET
echo ===============================================================================
echo.
echo Desativando HPET no bcdedit e no gerenciador para evitar gargalos de clock...
bcdedit /deletevalue useplatformclock >nul 2>&1
echo.
echo [CONCLUIDO] HPET desativado! Mais fluidez em FPS de jogos competitivos.
echo.
pause
