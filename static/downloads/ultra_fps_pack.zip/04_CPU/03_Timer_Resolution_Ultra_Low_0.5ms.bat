@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Timer Resolution & Clock Tick Latency
color 0C
echo ===============================================================================
echo                   APEX BOOST - TIMER RESOLUTION 0.5MS
echo ===============================================================================
echo.
echo Ajustando parametros de bcdedit para menor latencia de ticks do processador...
bcdedit /set useplatformclock false >nul 2>&1
bcdedit /set useplatformtick yes >nul 2>&1
bcdedit /set disabledynamictick yes >nul 2>&1
echo.
echo [CONCLUIDO] Latencia de interrupcao de clock reduzida para o menor valor possivel!
echo.
pause
