@echo off
title Apex Boost Labs - Desativar Bloatware e Notificacoes Inuteis
color 0E
echo ===============================================================================
echo                    APEX BOOST - DESATIVAR BLOATWARE
echo ===============================================================================
echo.
echo Desativando sugestoes de anuncios, Cortana e notificacoes invasivas...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338388Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SoftLandingEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications" /v "ToastEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCortana" /t REG_DWORD /d 0 /f >nul 2>&1
echo.
echo [CONCLUIDO] Notificacoes e anuncios de fundo desativados com sucesso!
echo.
pause
