@echo off
title Apex Boost Labs - Reverter Todas as Configuracoes
color 0C
echo ===============================================================================
echo                APEX BOOST - REVERTER PARA PADRAO DO WINDOWS
echo ===============================================================================
echo.
echo Restaurando configuracoes padrao de rede, timers e energia do Windows...
echo.

echo 1. Restaurando pilha TCP/IP padrao...
netsh int ip reset >nul 2>&1
netsh int tcp reset >nul 2>&1
netsh winsock reset >nul 2>&1

echo 2. Restaurando timers bcdedit padrao...
bcdedit /deletevalue useplatformclock >nul 2>&1
bcdedit /deletevalue useplatformtick >nul 2>&1
bcdedit /deletevalue disabledynamictick >nul 2>&1

echo 3. Restaurando plano de energia Equilibrado padrao...
powercfg -restoredefaultschemes >nul 2>&1

echo 4. Restaurando servicos essenciais do Windows...
sc config "DiagTrack" start=auto >nul 2>&1
sc start "DiagTrack" >nul 2>&1

echo.
echo [CONCLUIDO] Configuracoes restauradas para o padrao de fabrica do Windows!
echo Recomendamos reiniciar o computador agora.
echo.
pause
