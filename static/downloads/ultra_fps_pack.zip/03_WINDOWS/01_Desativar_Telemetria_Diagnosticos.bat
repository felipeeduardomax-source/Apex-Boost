@echo off
title Apex Boost Labs - Desativar Telemetria e Diagnosticos
color 0E
echo ===============================================================================
echo                   APEX BOOST - PRIVACIDADE & ALIVIO DE CPU
echo ===============================================================================
echo.
echo Desativando servicos de rastreamento e telemetria...
sc stop "DiagTrack" >nul 2>&1
sc config "DiagTrack" start=disabled >nul 2>&1
sc stop "dmwappushservice" >nul 2>&1
sc config "dmwappushservice" start=disabled >nul 2>&1

echo Ajustando chaves de registro de telemetria...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy" /v "TailoredExperiencesWithDiagnosticDataEnabled" /t REG_DWORD /d 0 /f >nul 2>&1

echo.
echo [CONCLUIDO] Telemetria e servicos em segundo plano desativados!
echo.
pause
