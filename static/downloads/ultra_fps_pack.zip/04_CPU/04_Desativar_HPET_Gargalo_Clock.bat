@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Desativar HPET (High Precision Event Timer)
color 0C
echo ===============================================================================
echo                      APEX BOOST - DESATIVAR HPET
echo ===============================================================================
echo.
echo Desativando HPET no bcdedit e no gerenciador para evitar gargalos de clock...
bcdedit /deletevalue useplatformclock >nul 2>&1
echo.
echo [CONCLUIDO] HPET desativado! Mais fluidez em FPS de jogos competitivos.
echo.
pause
