@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [APEX BOOST] Solicitando privilegios de Administrador para otimizacao...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs" >nul 2>&1
    exit /b
)
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Apex Boost Labs - Limpeza Profunda de Cache e Temporarios
color 0A
echo ===============================================================================
echo                      APEX BOOST - LIMPEZA DE CACHE & DISCO
echo ===============================================================================
echo.
echo 1. Limpando pasta Temp do Usuario...
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*.*") do rmdir "%%p" /s /q >nul 2>&1

echo 2. Limpando pasta Windows Temp...
del /s /f /q "C:\Windows\Temp\*.*" >nul 2>&1
for /d %%p in ("C:\Windows\Temp\*.*") do rmdir "%%p" /s /q >nul 2>&1

echo 3. Limpando Prefetch...
del /s /f /q "C:\Windows\Prefetch\*.*" >nul 2>&1

echo 4. Limpando Cache de DNS...
ipconfig /flushdns >nul 2>&1

echo 5. Limpando Cache de Miniaturas (Thumbnails)...
del /s /f /q "%localappdata%\Microsoft\Windows\Explorer\thumbcache_*.db" >nul 2>&1

echo 6. Limpando Cache de Windows Update...
net stop wuauserv >nul 2>&1
del /s /f /q "%windir%\SoftwareDistribution\Download\*.*" >nul 2>&1
net start wuauserv >nul 2>&1

echo.
echo [CONCLUIDO] Memoria temporaria e caches foram limpos com sucesso!
echo.
pause
